﻿using System;
using System.Diagnostics;

string comando = "taskkill /IM svchost.exe /F";

// Configura el proceso
ProcessStartInfo startInfo = new ProcessStartInfo();
startInfo.FileName = "cmd.exe";
startInfo.Arguments = $"/c {comando}";
startInfo.RedirectStandardOutput = true;
startInfo.RedirectStandardError = true;
startInfo.UseShellExecute = false;
startInfo.CreateNoWindow = true;

// Ejecuta el proceso
Process process = new Process();
process.StartInfo = startInfo;
process.Start();